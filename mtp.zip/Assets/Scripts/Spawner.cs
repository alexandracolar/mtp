﻿using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject obstaclePrefab;
    public float spawnRate = 2.5f;
    public float heightRange = 2f;
    public float spawnX = 5f; 

    private float timer;

    private void Awake()
    {
        if (GameManager.Instance == null)
        {
            new GameObject("GameManager").AddComponent<GameManager>();
        }

        if (ScoreManager.Instance == null)
        {
            new GameObject("ScoreManager").AddComponent<ScoreManager>();
        }
    }

    private void Start()
    {
        RemoveManuallyPlacedObstacles();
        SpawnPipePair();
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnRate)
        {
            SpawnPipePair();
            timer = 0;
        }
    }

    void SpawnPipePair()
    {
        if (obstaclePrefab == null)
        {
            Debug.LogError("obstaclePrefab not assigned!");
            return;
        }

        float randomY = Random.Range(-heightRange, heightRange);

        Vector3 spawnPos = new Vector3(spawnX, randomY, 0);
        GameObject obstacle = Instantiate(obstaclePrefab, spawnPos, Quaternion.identity);

        foreach (Pipes pipe in obstacle.GetComponentsInChildren<Pipes>())
        {
            pipe.enabled = false;
        }

        if (obstacle.GetComponent<MoveLeft>() == null)
        {
            obstacle.AddComponent<MoveLeft>();
        }

        if (obstacle.GetComponent<DestroyOffScreen>() == null)
        {
            obstacle.AddComponent<DestroyOffScreen>();
        }

        AddScoreZone(obstacle);

        Debug.Log($"Spawned pipe pair at Y: {randomY}");
    }

    private void AddScoreZone(GameObject obstacle)
    {
        GameObject scoreZone = new GameObject("ScoreZone");
        scoreZone.transform.SetParent(obstacle.transform, false);
        scoreZone.transform.localPosition = Vector3.zero;

        BoxCollider2D collider = scoreZone.AddComponent<BoxCollider2D>();
        collider.isTrigger = true;
        collider.size = new Vector2(0.35f, 2f);

        scoreZone.AddComponent<ScoreZone>();
    }

    private void RemoveManuallyPlacedObstacles()
    {
        foreach (Transform sceneObject in FindObjectsByType<Transform>())
        {
            if (sceneObject.parent == null && sceneObject.name.Contains("Obstacol"))
            {
                Destroy(sceneObject.gameObject);
            }
        }
    }
} // Aceasta este acolada care îți lipsea și închide clasa!
