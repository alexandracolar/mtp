using UnityEngine;

public class DestroyOffScreen : MonoBehaviour
{
    private float destroyDistance = 15f;

    void Update()
    {
        if (transform.position.x < -destroyDistance)
        {
            Destroy(gameObject);
        }
    }
}
