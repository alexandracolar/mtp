using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    private int score;
    private GUIStyle scoreStyle;
    private GUIStyle startStickerStyle;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        scoreStyle = new GUIStyle
        {
            fontSize = 48,
            alignment = TextAnchor.UpperCenter,
            normal = { textColor = Color.white }
        };

        startStickerStyle = new GUIStyle
        {
            fontSize = 34,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            normal = { textColor = Color.white }
        };
    }

    public void AddPoint()
    {
        score++;
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(0, 20, Screen.width, 70), score.ToString(), scoreStyle);

        if (GameManager.Instance != null && !GameManager.Instance.HasStarted)
        {
            Rect stickerRect = new Rect((Screen.width - 360) / 2f, Screen.height * 0.42f, 360, 86);
            GUI.color = new Color(0f, 0f, 0f, 0.65f);
            GUI.Box(stickerRect, GUIContent.none);
            GUI.color = Color.white;
            GUI.Label(stickerRect, "pause for start", startStickerStyle);
        }
    }
}
