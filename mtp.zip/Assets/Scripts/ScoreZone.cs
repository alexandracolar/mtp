using UnityEngine;

public class ScoreZone : MonoBehaviour
{
    private bool scored;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (scored || other.GetComponent<PlayerController>() == null)
        {
            return;
        }

        scored = true;

        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.AddPoint();
        }
    }
}
